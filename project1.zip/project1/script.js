const $ = (id) => document.getElementById(id);

const studentForm = $("studentForm");
const studentTableBody = $("studentTableBody");
const searchInput = $("searchInput");

let students = [];
let editingId = null;

// Load saved students when the page opens
try {
    const savedStudents = localStorage.getItem("studentHubStudents");
    students = savedStudents ? JSON.parse(savedStudents) : [];

    if (!Array.isArray(students)) {
        students = [];
    }
} catch (error) {
    console.error("Error loading students:", error);
    students = [];
}

// Save students to browser storage
function saveStudents() {
    try {
        localStorage.setItem(
            "studentHubStudents",
            JSON.stringify(students)
        );
        return true;
    } catch (error) {
        console.error("Error saving students:", error);
        alert("Unable to save students. Please check browser storage.");
        return false;
    }
}

// Add or update a student
studentForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const name = $("studentName").value.trim();
    const roll = $("rollNumber").value.trim();
    const department = $("department").value;
    const email = $("studentEmail").value.trim();

    if (!name || !roll || !department || !email) {
        alert("Please fill in all student details.");
        return;
    }

    // Check duplicate roll numbers
    const duplicate = students.some(student =>
        student.roll.toLowerCase() === roll.toLowerCase() &&
        student.id !== editingId
    );

    if (duplicate) {
        alert("This roll number already exists.");
        return;
    }

    if (editingId) {
        const student = students.find(s => s.id === editingId);

        if (student) {
            student.name = name;
            student.roll = roll;
            student.department = department;
            student.email = email;
        }
    } else {
        students.push({
            id: Date.now().toString() + Math.random().toString(16).slice(2),
            name: name,
            roll: roll,
            department: department,
            email: email,
            attendance: "Not marked",
            marks: ""
        });
    }

    // Save before refreshing the page display
    if (saveStudents()) {
        studentForm.reset();
        studentForm.hidden = true;
        editingId = null;

        $("formTitle").textContent = "Add New Student";
        $("addStudentBtn").textContent = "+ Add Student";

        renderStudents();
        alert("Student saved successfully!");
    }
});

// Show students in the table
function renderStudents() {
    const query = searchInput.value.trim().toLowerCase();

    const filteredStudents = students.filter(student =>
        [
            student.name,
            student.roll,
            student.department,
            student.email
        ].some(value => String(value).toLowerCase().includes(query))
    );

    studentTableBody.replaceChildren();

    if (filteredStudents.length === 0) {
        const row = document.createElement("tr");
        const cell = document.createElement("td");

        cell.colSpan = 5;
        cell.className = "empty-state";
        cell.textContent = students.length === 0
            ? "No students added yet."
            : "No matching students found.";

        row.appendChild(cell);
        studentTableBody.appendChild(row);
    }

    filteredStudents.forEach(student => {
        const row = document.createElement("tr");

        [
            student.name,
            student.roll,
            student.department,
            student.email
        ].forEach(value => {
            const cell = document.createElement("td");
            cell.textContent = value;
            row.appendChild(cell);
        });

        const actions = document.createElement("td");

        // Edit button
        const editButton = document.createElement("button");
        editButton.type = "button";
        editButton.textContent = "Edit";

        editButton.addEventListener("click", function () {
            editingId = student.id;

            $("studentName").value = student.name;
            $("rollNumber").value = student.roll;
            $("department").value = student.department;
            $("studentEmail").value = student.email;

            $("formTitle").textContent = "Edit Student";
            $("addStudentBtn").textContent = "Editing Student";

            studentForm.hidden = false;
            studentForm.scrollIntoView({ behavior: "smooth" });
        });

        // Delete button
        const deleteButton = document.createElement("button");
        deleteButton.type = "button";
        deleteButton.textContent = "Delete";

        deleteButton.addEventListener("click", function () {
            if (confirm("Delete " + student.name + "?")) {
                students = students.filter(
                    item => item.id !== student.id
                );

                if (saveStudents()) {
                    renderStudents();
                }
            }
        });

        actions.append(editButton, deleteButton);
        row.appendChild(actions);
        studentTableBody.appendChild(row);
    });

    $("studentCount").textContent =
        filteredStudents.length +
        (filteredStudents.length === 1 ? " student" : " students");

    $("totalStudents").textContent = students.length;

    const departments = new Set(
        students.map(student => student.department)
    );

    $("totalDepartments").textContent = departments.size;
}

// Open the Add Student form
$("addStudentBtn").addEventListener("click", function () {
    editingId = null;
    studentForm.reset();

    $("formTitle").textContent = "Add New Student";
    $("addStudentBtn").textContent = "+ Add Student";

    studentForm.hidden = false;
});

// Cancel the form
$("cancelFormBtn").addEventListener("click", function () {
    studentForm.reset();
    studentForm.hidden = true;
    editingId = null;

    $("formTitle").textContent = "Add New Student";
    $("addStudentBtn").textContent = "+ Add Student";
});

// Search students
searchInput.addEventListener("input", renderStudents);

// Initial display
renderStudents();