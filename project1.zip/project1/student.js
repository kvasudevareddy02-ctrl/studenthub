
const tableBody = document.getElementById("studentTableBody");
const searchInput = document.getElementById("searchStudents");
const studentCount = document.getElementById("studentCount");

function getStudents() {
    try {
        const data = JSON.parse(
            localStorage.getItem("studentHubStudents") || "[]"
        );

        return Array.isArray(data) ? data : [];
    } catch (error) {
        console.error("Could not load students:", error);
        return [];
    }
}

function displayStudents() {
    const students = getStudents();
    const query = searchInput.value.trim().toLowerCase();

    const filtered = students.filter(student =>
        [
            student.name,
            student.roll,
            student.department,
            student.email
        ].some(value =>
            String(value || "").toLowerCase().includes(query)
        )
    );

    tableBody.replaceChildren();

    if (filtered.length === 0) {
        const row = document.createElement("tr");
        const cell = document.createElement("td");

        cell.colSpan = 5;
        cell.textContent = students.length === 0
            ? "No saved students found."
            : "No matching students found.";

        row.appendChild(cell);
        tableBody.appendChild(row);
    }

    filtered.forEach(student => {
        const row = document.createElement("tr");

        // Student name
        const nameCell = document.createElement("td");
        nameCell.textContent = student.name || "Unnamed";
        row.appendChild(nameCell);

        // Roll number
        const rollCell = document.createElement("td");
        const rollLink = document.createElement("a");

        rollLink.textContent = student.roll || "View profile";
        rollLink.href =
            "student-profile.html?roll=" +
            encodeURIComponent(student.roll || "");

        rollCell.appendChild(rollLink);
        row.appendChild(rollCell);

        // Department
        const deptCell = document.createElement("td");
        deptCell.textContent =
            student.department || "Not available";
        row.appendChild(deptCell);

        // Email
        const emailCell = document.createElement("td");
        emailCell.textContent =
            student.email || "Not available";
        row.appendChild(emailCell);

        // Actions
        const actionCell = document.createElement("td");

        const profileLink = document.createElement("a");
        profileLink.textContent = "Open Profile";
        profileLink.href =
            "student-profile.html?roll=" +
            encodeURIComponent(student.roll || "");

        profileLink.style.display = "inline-block";
        profileLink.style.backgroundColor = "#2563eb";
        profileLink.style.color = "white";
        profileLink.style.padding = "10px 16px";
        profileLink.style.borderRadius = "8px";
        profileLink.style.textDecoration = "none";

        actionCell.appendChild(profileLink);
        row.appendChild(actionCell);

        tableBody.appendChild(row);
    });

    studentCount.textContent =
        filtered.length +
        (filtered.length === 1 ? " student" : " students");
}

// Search students
searchInput.addEventListener("input", displayStudents);

// Display saved students when the page opens
displayStudents();